import Service from './Service';

class SliderService extends Service {
  constructor(model) {
    super(model);
  }
}
export default SliderService;
